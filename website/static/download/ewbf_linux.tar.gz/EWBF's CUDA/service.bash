#!/bin/sh
screen -dm -S Asofe bash -c "$(pwd)/miner"
